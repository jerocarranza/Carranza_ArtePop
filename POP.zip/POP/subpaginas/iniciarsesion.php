<html lang=es>
<head>
    
        <meta charset=utf-8>
        <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">
    
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link rel=stylesheet href="../css/estyle.css">
        <link rel="shortcut icon" href="../img/icons/icon.ico.jpg">
        <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel=stylesheet>
        <title>ArtePop</title>
</head>
<body>

 
<nav class="navbar navbar-light bg-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="../index.html"><img src="../img/logo.jpg" style="height: 5%; width: 5%;"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Conoce un poco más</h5>
          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="../index.html">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../subpaginas/acercade.html">Acerca del arte Pop</a>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="../subpaginas/obras.html">Obras</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../subpaginas/artistas.html">Artistas</a>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="../subpaginas/iniciarsesion.php">Iniciar sesion</a>
            </li>
           
          </ul>
          <form action="../subpaginas/resultados.php" method="post" class="d-flex">
            <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search" name="buscar">
            <button class="btn btn-outline-success" type="submit" value="Enviar">Buscar</button>
          </form>
        </div>
      </div>
    </div>
  </nav>


        <div class=container-fluid> 
                <div class=separador>
                    <figure>
                      <img class="img-fluid trans1" src=../img/banner/banner6.png alt="">
                    </figure>
                </div>
        </div>

        <div class="conteiner-fluid acerca1">
        <div class=container>
            <div class=row>
              <h1  style="text-align: center;">Ser parte de la comunidad</h1>
                <hr>
              <p>Hazte una cuenta dentro del sitio para poder acceder a contenido exclusivo. Cada semana estaremos revelando nuevos <b>artistas, obras y datos curiosos</b> para que sigas conociendo esta vanguardia tan espectacular. </p>
            </div>
        </div>
    </div>




<article style="width:100%; margin:0 auto ;padding:0px; font-size: x-large; text-align: center; color: #05765F">
<?php
if (array_key_exists("registro", $_GET)){
  
  echo "Usuario registrado correctamente, por favor iniciar sesión"; 

}
?>
</article>



<div style="background-color: #181C5C; color: #B5B6C2; font-size:large;" class="conteiner-fluid acerca2">
  <div class=container-fluid>
   <div class=container>
    <div class=row>



              <div class="col">
                <div>
                    <h2>Logueate</h2>
                       <form action="login.php" method="post"><input type='hidden' name='form-name' value='form 1' /><input type=hidden name=formsumate value="form 3">
                       <label for="exampleInputEmail1" class="form-label">Usuario
                       <input class=form-control name="usuario" type="text" maxlength="12" required/>
                       </label><br/>
                       <label for="exampleInputEmail1" class="form-label">Contraseña
                       <input class=form-control type="password" name="password" maxlength="12" required/>
                       </label><br/><br/>
                       <input class=form-control type="submit" value="Iniciar sesión"/>	
                       </form>
                </div>
              </div>

              <div class="col">
            <img src="../img/obras/pequenas/gatos.jpg"/>
    </div>

              <div class="col">
                <div>
                    <h2>Registrate</h2>
                      <form action="registro.php" method="post" ><input type='hidden' name='form-name' value='form 1' /><input type=hidden name=formsumate value="form 3">
                      <label>Nombre
                      <input class=form-control type="text" name="nombre" required />
                      </label><br/>
                      <label>Apellido
                      <input class=form-control type="text" name="apellido" required />
                      </label><br/>
                      <label>Email
                      <input class=form-control type="email" name="email" required />
                      </label><br/>
                      <label>Usuario
                      <input class=form-control name="usuario" type="text" maxlength="12" required />
                      </label><br/>
                      <label>Contraseña
                      <input class=form-control type="password" name="password" maxlength="12" required />
                      </label><br/><br/>
                      <input class=form-control class="btn btn-primary" type="submit" value="Registrarse"/>	
                      </form>
                  </div>
                </div>

      </div>
    </div>
  </div>
</div>






<div class=container-fluid> 
        <div class=separador>
            <figure>
              <img class="img-fluid trans1" src=../img/banner/banner7.png alt="">
            </figure>
        </div>
    </div>

<div class="conteiner-fluid">
      <div class=row>
             <div class="col-md-6">
                      <div class=footer>
                        <a href="../subpaginas/suscribite.html" style="text-decoration: none;"> <h2>Suscribite</h2></a>
                      </div>
              </div>
              <div class="col-md-6">
                      <div class=footer>
                        <a href="../subpaginas/quienes.html" style="text-decoration: none;"><h2>Quienes Somos</h2></a>
                      </div>
              </div>
      </div>
    </div>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
