<?php session_start();

if (array_key_exists("logueado", $_SESSION) and $_SESSION["logueado"]=="ok"){

?>

<html lang=es>
<head>
    
        <meta charset=utf-8>
        <meta name=viewport content="width=device-width,initial-scale=1,shrink-to-fit=no">
    
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link rel=stylesheet href="../css/estyle.css">
        <link rel="shortcut icon" href="../img/icons/icon.ico.jpg">
        <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel=stylesheet>
        <link rel=stylesheet href="../lightbox2-2.11.3/lightbox2-2.11.3/src/css/lightbox.css">
        <title>Acerca del ArtePop</title>
</head>


<body>

  <nav class="navbar navbar-light bg-light sticky-top">
    <div class="container-fluid">
    <a class="navbar-brand" href="index.html"><img src="../img/logo.jpg" style="height: 5%; width: 5%;"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Conoce un poco más</h5>
          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../subpaginas/acercade.html">Acerca del arte Pop</a>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="../subpaginas/obras.html">Obras</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../subpaginas/artistas.html">Artistas</a>
            </li>
            <li class="nav-item">
                    <a class="nav-link" href="../index.html">Iniciar sesion</a>
            </li>
           
          </ul>
          <form action="../subpaginas/resultados.php" method="post" class="d-flex">
            <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search" name="buscar">
            <button class="btn btn-outline-success" type="submit" value="Enviar">Buscar</button>
          </form>
        </div>
      </div>
    </div>
</nav>


<h2>CONTENIDO EXCLUSIVO DE ESTA SEMANA</h2>

<div style="background-color: #FC1E8B; color: #161213;" class="conteiner-fluid obras">
        <div class=container>
            <div class=row>
              <h1 style="text-align: center;">MARTA MINUJIN</h1>
                <hr>
              <p  style="text-align: center;"><b>1943</p>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
  
          <div class="imgobra">
          <img src="../img/artistas/minujin.jpg">
          </div>
        </div>
    </div>


    <div style="background-color: #05765F; color: #161213;" class="conteiner-fluid acerca2">
        <div class=container>
            <div class=row>
    
              <p><b>Marta Inés Minujín</b> (Buenos Aires; 30 de enero de 1943) es una artista plástica argentina, conocida por sus obras vanguardistas producidas principalmente durante los años 1960, 1970 y 1980. Su obra, de carácter <b>conceptual, pop, psicodélico y de acción</b>, entra en la generación baby boomer que, en los años 1960, revolucionó las normas sociales preestablecidas y estableció una contracultura. Es la tía del actor Juan Minujín.</p>
              <br>
            
              <p>La obra de <b>Lichtenstein</b> se caracteriza por su ironía (es algo de lo que los <b>artistas pop</b> presumían, a veces disfrazado de snobismo o superficialidad…), el uso de <b>puntos benday</b> (utilizados en <b>artes gráficas</b>) y <b>colores industriales</b>, el lenguaje del <b>cómic</b>(onomatopeyas, viñetas, narrativa) y el dominio de la <b>línea</b>.</p>
            
            </div>
        </div>
    </div>


    <div class=container-fluid> 
        <div class=separador>
            <figure>
              <img class="img-fluid trans1" src=../img/banner/banner6.png alt="">
            </figure>
        </div>
    </div>

<div style="background-color: #FA832F; color: #161213;" class="conteiner-fluid acerca2">
    <div class=container>
        <div class=row>

        <p>Comenzó a realizar estructuras habitables, cubiertas de colchones encontrados entre los desechos de los hospitales parisinos. En el baldío del Impasse Roussin, realizó <b>“La Destrucción” (1963)</b>, su primer happening, para esta obra reunió todas sus piezas con colchones e invitó a un grupo de "artistas" a “destruirlas” </p>
        
        </div>
    </div>
</div>

<div class=container-fluid> 
    <div class=separador>
        <figure>
          <img class="img-fluid trans1" src=../img/banner/banner7.png alt="">
        </figure>
    </div>
</div>

<div style="background-color: #F91740; color: #161213;" class="conteiner-fluid acerca2">
    <div class=container>
        <div class=row>

        <p>En 1966 obtuvo la beca <b>Guggenheim</b> y se fue a vivir por 10 años -con leves interrupciones- a Nueva York. Desde 1980 Minujín realiza esculturas con apropiaciones de obras clásicas de la estatuaria greco-romana, de la renacentista, y hasta de las estatuillas cicládicas. Sus obras son reproducciones en yeso de esos modelos, fragmentados, desarticulados en secciones desplazadas.</p>
        
        </div>
    </div>
</div>


<div class="container padre">
    <div class="row hijo">

        <h2 style="padding: 50px; color: #161213;">Obras del artista</h2>

      <div class="col-sm-12 col-md-6 col-lg-4 imgobrasyartistas">
        <a href="../img/obras/pequenas/marta1.jpg" data-lightbox="roadtrip"><img src="../img/obras/pequenas/marta1.jpg"></a>
      </div>

      <div class="col-sm-12 col-md-6 col-lg-4 imgobrasyartistas">
        <a href="../img/obras/pequenas/marta2.jpg" data-lightbox="roadtrip"><img src="../img/obras/pequenas/marta2.jpg"></a>
      </div>


      <div class="col-sm-12 col-md-6 col-lg-4 imgobrasyartistas">
        <a href="../img/obras/pequenas/marta4.jpg" data-lightbox="roadtrip"><img src="../img/obras/pequenas/marta4.jpg"></a>
      </div>

      <div class="col-sm-12 col-md-6 col-lg-4 imgobrasyartistas">
        <a href="../img/obras/pequenas/marta3.jpg" data-lightbox="roadtrip"><img src="../img/obras/pequenas/marta3.jpg"></a>
      </div>

    </div>
</div>

<h2><a href="salir.php">SALIR</a></h2>


<div class="conteiner-fluid">
      <div class=row>
             <div class="col-md-6">
                      <div class=footer>
                        <a href="../subpaginas/suscribite.html" style="text-decoration: none;"> <h2>Suscribite</h2></a>
                      </div>
              </div>
              <div class="col-md-6">
                      <div class=footer>
                        <a  href="../subpaginas/quienes.html" style="text-decoration: none;"><h2>Quienes Somos</h2></a>
                      </div>
              </div>
      </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

<?php }  else {
    header('Location:iniciarsesion.php');
}

?>

<script
              src="https://code.jquery.com/jquery-3.6.0.min.js"
              integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
              crossorigin="anonymous"></script>

<script src="../lightbox2-2.11.3/lightbox2-2.11.3/src/js/lightbox.js"></script>


<script>
    lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })
</script>

</body>