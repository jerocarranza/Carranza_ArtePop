<?php session_start();?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
</head>

<body>


        
<article style="width:100%; margin:0 auto ;padding:0px; font-size: x-large; text-align: center; color: #F91740">

<?php
$usuario = $_POST['usuario'];
$password = md5($_POST['password']);

include("conexion.php");

$consulta = mysqli_query($conexion, "SELECT nombre, apellido, email FROM usuarios WHERE usuario='$usuario' AND password='$password'");

$resultado = mysqli_num_rows($consulta);

if($resultado!=0){
	$respuesta=mysqli_fetch_array($consulta);
		echo "Hola ".$respuesta['nombre']." ".$respuesta['apellido']."<br />";
		echo "te damos el acceso al secreto de la vida.";
		echo "<a href='http://www.google.com'>El secreto</a>";	
		$_SESSION['logueado']="ok";
		header('Location:exclusivo.php');


} else {
	echo "Parece que no hay un usuario registrado con esos datos, vuelve a intentarlo o genera un nuevo usuario";
	include ("iniciarsesion.php");
}


?>

</body>
</html>